<?php include "header.php"; ?>


<!-- Testimonial Section Starts -->
<section class="login-sec">
    <br/><br/>
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
            <input type="text" name="username" id="username" placeholder="Enter Your Username" />
            <br/><br/>
            <input type="password" name="password" id="password" placeholder="Enter Your Password" />
            <br/><br/>
            <center><a  class="btn btn-woodapple" id="login-btn">Login</a></center>
        </div>
        <div class="col-sm-4"></div>        
    </div>
</section>
<!-- Testimonial Section Ends -->


<?php include "footer.php"; ?>